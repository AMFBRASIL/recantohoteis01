<?php

return [
    'openstreetmap' => [
        'script' => 'https://www.facebook.com/scotchdevelopment',
    ],
    'googlemap' => [
        'script' => 'https://www.facebook.com/scotchdevelopment',
    ],
];