<div class="b-footer" style="margin-top: 0px;">
    <div class="b-container">
        {!! setting_item_with_lang('email_footer') !!}
    </div>
</div>